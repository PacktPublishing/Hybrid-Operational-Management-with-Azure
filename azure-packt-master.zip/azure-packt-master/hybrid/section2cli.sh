#!/bin/bash
group="PacktPublishing"
location="southcentralus"